#from .execute import execute as fit
from .version import version
from .execute import fit

# def fit(d):
#     return {
#         'source_points': [[0,0],[0,0]],
#         'saccade_points': [[0,0], [1,1], [2,2], [3,3], [4,4], [5,5]],
#         'target_points': [[5,5],[5,5]],
#     }
